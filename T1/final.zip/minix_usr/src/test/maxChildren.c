#include <stdio.h>
#include <lib.h>
#include <unistd.h>
int main( int argc, char ** argv )
{
	int i;
	message m;
	int ret;
	int children;
	if( argc != 2)
		return 0;
	children = atoi(argv[1]);
	printf("create %d children\n", children);
	for( i = 0; i < children; ++ i )
	{
		if( fork() == 0 )
		{
			sleep( 5 );
			return 0;
		}
	}
	sleep( 1 ); 
	_syscall( MM, MAXCHILDREN, &m );
	printf( "Max children: %d\n", m.m1_i1 );
	printf( "pid: %d\n", m.m1_i2);
	return 0;	
}
