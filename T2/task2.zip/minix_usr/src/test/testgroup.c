#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <lib.h>

int main(int argc, char *argv[]) {
	int new_group;
	message m;
	pid_t pid = getpid();
	int result;
	if (argc != 2) {
     		return 1;
    	}
	new_group = atoi(argv[1]);
	m.m1_i1 = pid;
	m.m1_i2 = new_group;
	result = _syscall( MM, CHANGEPROCGROUP, &m );
	
	while(1) {
	}
	return 0;
}

